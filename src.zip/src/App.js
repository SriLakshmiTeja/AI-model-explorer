// App.js
import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom'; // Import BrowserRouter and Route
import HomePage from './pages/HomePage';
import BrowseModelsPage from './pages/BrowseModelsPage';
import FeaturedModelsPage from './pages/FeaturedModelsPage';
import ModelDetailsPage from './pages/ModelDetailsPage';
import UploadModelInfoPage from './pages/UploadModelInfoPage';
import TryItOutPage from './pages/TryItOutPage';

const App = () => {
  return (
    <Router>
      <Route exact path="/" component={HomePage} />
      <Route path="/browse-models" component={BrowseModelsPage} />
      <Route path="/featured-models" component={FeaturedModelsPage} />
      <Route path="/model-details/:id" component={ModelDetailsPage} />
      <Route path="/upload-model-info" component={UploadModelInfoPage} />
      <Route path="/try-it-out" component={TryItOutPage} />
    </Router>
  );
};

export default App;
