// src/pages/UploadModelInfoPage.js
import React from 'react';

const UploadModelInfoPage = () => {
  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = new FormData(event.target);

    try {
      const response = await fetch('http://localhost:3000/upload-model-info', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        console.log('Model information uploaded successfully!');
        // Optionally, you can redirect the user to another page after successful upload
      } else {
        console.error('Failed to upload model information');
      }
    } catch (error) {
      console.error('Error uploading model information:', error);
    }
  };

  return (
    <div>
      <h1>Upload Model Information</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="modelName">Model Name:</label>
          <input type="text" id="modelName" name="modelName" required />
        </div>
        <div>
          <label htmlFor="category">Category:</label>
          <input type="text" id="category" name="category" required />
        </div>
        <div>
          <label htmlFor="provider">Provider:</label>
          <input type="text" id="provider" name="provider" required />
        </div>
        <div>
          <label htmlFor="description">Description:</label>
          <textarea id="description" name="description" rows="4" required></textarea>
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default UploadModelInfoPage;
