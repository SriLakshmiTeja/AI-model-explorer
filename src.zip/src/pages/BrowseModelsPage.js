// src/pages/BrowseModelsPage.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Grid, Card, CardContent, Typography } from '@mui/material';

const BrowseModelsPage = () => {
  const [models, setModels] = useState([]);

  useEffect(() => {
    const fetchModels = async () => {
      try {
        const response = await axios.get('https://jsonplaceholder.typicode.com/models');
        setModels(response.data);
      } catch (error) {
        console.error('Error fetching models:', error);
      }
    };

    fetchModels();
  }, []);

  return (
    <div>
      <h1>Browse Models</h1>
      <Grid container spacing={3}>
        {models.map(model => (
          <Grid item xs={12} sm={6} md={4} key={model.id}>
            <Card>
              <CardContent>
                <Typography variant="h6" component="h2">
                  {model.name}
                </Typography>
                <Typography color="textSecondary" gutterBottom>
                  Category: {model.category}
                </Typography>
                <Typography color="textSecondary" gutterBottom>
                  Provider: {model.provider}
                </Typography>
                <Typography variant="body2" component="p">
                  Description: {model.description}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </div>
  );
};

export default BrowseModelsPage;
