// src/pages/TryItOutPage.js
import React, { useState } from 'react';

const TryItOutPage = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');

  const handleTryItOut = async (event) => {
    event.preventDefault();

    try {
      const response = await fetch('http://localhost:3000/try-it-out', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ input }),
      });

      if (response.ok) {
        const data = await response.json();
        setOutput(data.output);
      } else {
        console.error('Failed to try out the model');
      }
    } catch (error) {
      console.error('Error trying out the model:', error);
    }
  };

  return (
    <div>
      <h1>Try It Out</h1>
      <form onSubmit={handleTryItOut}>
        <div>
          <label htmlFor="input">Input:</label>
          <textarea id="input" name="input" rows="4" value={input} onChange={(e) => setInput(e.target.value)} required></textarea>
        </div>
        <button type="submit">Try It Out</button>
      </form>
      <div>
        <h2>Output:</h2>
        <p>{output}</p>
      </div>
    </div>
  );
};

export default TryItOutPage;
