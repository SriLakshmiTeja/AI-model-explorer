// src/pages/HomePage.js
import React from 'react';

const HomePage = () => {
  return (
    <div>
      <h1>AI Model Explorer</h1>
      <p>Welcome to AI Model Explorer, your platform for discovering and exploring various AI models!</p>
      {/* Add content or components as needed */}
    </div>
  );
};

export default HomePage;
