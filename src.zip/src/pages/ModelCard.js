// components/ModelCard.js
import React from 'react';
import { Card, CardContent, Typography } from '@mui/material';

const ModelCard = ({ model }) => {
  return (
    <Card>
      <CardContent>
        <Typography variant="h6" component="h2">
          {model.name}
        </Typography>
        <Typography color="textSecondary" gutterBottom>
          Category: {model.category}
        </Typography>
        <Typography color="textSecondary" gutterBottom>
          Provider: {model.provider}
        </Typography>
        <Typography variant="body2" component="p">
          Description: {model.description}
        </Typography>
      </CardContent>
    </Card>
  );
};

export default ModelCard;
