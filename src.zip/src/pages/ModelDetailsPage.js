// src/pages/ModelDetailsPage.js
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { Typography } from '@mui/material';

const ModelDetailsPage = () => {
  const { id } = useParams();
  const [model, setModel] = useState(null);

  useEffect(() => {
    const fetchModelDetails = async () => {
      try {
        const response = await axios.get(`https://jsonplaceholder.typicode.com/models/${id}`);
        setModel(response.data);
      } catch (error) {
        console.error('Error fetching model details:', error);
      }
    };

    fetchModelDetails();
  }, [id]);

  return (
    <div>
      <h1>Model Details</h1>
      {model ? (
        <div>
          <Typography variant="h6" component="h2">{model.name}</Typography>
          <Typography variant="subtitle1" gutterBottom>Category: {model.category}</Typography>
          <Typography variant="subtitle1" gutterBottom>Provider: {model.provider}</Typography>
          <Typography variant="body1" gutterBottom>Description: {model.description}</Typography>
          {/* Add additional model details like code snippet and use cases */}
        </div>
      ) : (
        <Typography variant="body1">Loading...</Typography>
      )}
    </div>
  );
};

export default ModelDetailsPage;
